"""
Unit tests for Escalation and Safety Policy enforcement.
"""
import pytest
from src.policy import RiskAwarePolicyEngine, evaluate_risk_rules
from src.models import IntentResult


def test_hardware_hazard_escalation():
    engine = RiskAwarePolicyEngine()
    intent_res = IntentResult(intent="battery_power_hardware", confidence=0.95)
    decision = engine.decide("My battery is swollen and smells like smoke!", intent_res)
    assert decision.decision == "escalate_to_human"
    assert decision.category == "hardware_safety_hazard"
    assert len(decision.safety_triggers) > 0


def test_pii_security_escalation():
    engine = RiskAwarePolicyEngine()
    intent_res = IntentResult(intent="account_billing_subscription", confidence=0.90)
    decision = engine.decide("Someone hacked into my Apple ID and changed my recovery phone", intent_res)
    assert decision.decision == "escalate_to_human"
    assert decision.category == "pii_account_security"


def test_financial_dispute_escalation():
    engine = RiskAwarePolicyEngine()
    intent_res = IntentResult(intent="account_billing_subscription", confidence=0.88)
    decision = engine.decide("I have an unauthorized charge of $100 and want a refund", intent_res)
    assert decision.decision == "escalate_to_human"
    assert decision.category == "financial_dispute"


def test_low_confidence_gating():
    engine = RiskAwarePolicyEngine(confidence_cutoff=0.65)
    intent_res = IntentResult(intent="software_os_issue", confidence=0.45)
    decision = engine.decide("Something weird happens with the screen sometimes", intent_res)
    assert decision.decision == "escalate_to_human"
    assert decision.category == "low_model_confidence"


def test_safe_auto_handle():
    engine = RiskAwarePolicyEngine(confidence_cutoff=0.65)
    intent_res = IntentResult(intent="device_setup_how_to", confidence=0.92)
    decision = engine.decide("How do I take a screenshot on iPhone X?", intent_res)
    assert decision.decision == "auto_handle"
    assert decision.category == "none"
