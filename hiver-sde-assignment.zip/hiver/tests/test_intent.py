"""
Unit tests for Intent Classification.
"""
import pytest
from src.intent import (
    MajorityBaselineClassifier,
    TfidfLogisticBaselineClassifier,
    HybridLLMIntentClassifier,
    ALL_INTENTS
)


def test_majority_classifier():
    clf = MajorityBaselineClassifier(default_intent="software_os_issue")
    res = clf.predict("My screen is completely black and won't turn on")
    assert res.intent == "software_os_issue"
    assert res.confidence > 0.0


def test_tfidf_logistic_classifier():
    clf = TfidfLogisticBaselineClassifier()
    texts = [
        "My iOS update froze on the apple logo",
        "Battery is draining super fast",
        "Wi-Fi keeps dropping every few minutes",
        "Unauthorized charge on my credit card from iTunes",
        "How do I setup Quick Start on new iPhone",
        "I hate Apple this company is terrible"
    ]
    labels = [
        "software_os_issue",
        "battery_power_hardware",
        "connectivity_sync",
        "account_billing_subscription",
        "device_setup_how_to",
        "complaint_feedback"
    ]
    clf.fit(texts, labels)
    res = clf.predict("My phone is frozen after updating iOS")
    assert res.intent in ALL_INTENTS
    assert 0.0 <= res.confidence <= 1.0


def test_hybrid_intent_classifier():
    clf = HybridLLMIntentClassifier()
    # Test specific intent detections
    res_batt = clf.predict("My battery is swelling up and getting very hot")
    assert res_batt.intent == "battery_power_hardware"

    res_bill = clf.predict("Someone made an unauthorized purchase on my Apple ID")
    assert res_bill.intent == "account_billing_subscription"

    res_wifi = clf.predict("My Wi-Fi and Bluetooth disconnect constantly")
    assert res_wifi.intent == "connectivity_sync"
