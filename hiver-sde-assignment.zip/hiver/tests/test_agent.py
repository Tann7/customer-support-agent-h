"""
Integration test for end-to-end AppleSupportAgent.
"""
import pytest
from src.agent import AppleSupportAgent


def test_agent_end_to_end_auto_handle():
    agent = AppleSupportAgent()
    out = agent.process("How do I cancel my Apple Music subscription?")
    assert out.intent == "account_billing_subscription"
    assert out.escalation_decision == "auto_handle"
    assert len(out.draft_reply) > 10
    assert len(out.draft_reply) <= 280
    assert out.latency_ms > 0


def test_agent_end_to_end_escalation():
    agent = AppleSupportAgent()
    out = agent.process("My phone battery is smoking and burning my hand!")
    assert out.intent == "battery_power_hardware"
    assert out.escalation_decision == "escalate_to_human"
    assert out.escalation_category == "hardware_safety_hazard"
    assert "DM" in out.draft_reply or "https://apple.co/DM" in out.draft_reply
