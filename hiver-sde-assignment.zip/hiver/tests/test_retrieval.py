"""
Unit tests for Historical Knowledge Retrieval.
"""
import pytest
from src.response.retrieval import HistoricalKnowledgeRetriever


def test_retriever_initialization_and_search():
    retriever = HistoricalKnowledgeRetriever()
    assert len(retriever.records) > 0
    assert retriever.doc_matrix is not None

    query = "My battery is draining rapidly"
    results = retriever.retrieve(query, top_k=3)
    assert len(results) == 3
    for r in results:
        assert r.id is not None
        assert len(r.customer_query) > 0
        assert len(r.support_resolution) > 0
        assert r.relevance_score >= 0.0
