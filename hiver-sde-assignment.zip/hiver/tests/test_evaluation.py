"""
Unit tests for evaluation metrics and LLM-as-a-judge rubric.
"""
import pytest
from src.evaluation import (
    compute_intent_metrics,
    compute_escalation_metrics,
    calculate_rouge_l,
    calculate_bleu,
    LLMJudgeRubric
)


def test_intent_metrics():
    y_true = ["software_os_issue", "battery_power_hardware", "connectivity_sync"]
    y_pred = ["software_os_issue", "battery_power_hardware", "battery_power_hardware"]
    res = compute_intent_metrics(y_true, y_pred)
    assert 0.6 <= res["accuracy"] <= 0.7
    assert res["macro_f1"] > 0


def test_escalation_metrics_and_fahr():
    y_true = ["escalate_to_human", "auto_handle", "escalate_to_human"]
    # Model mistakenly auto-handles the first escalation
    y_pred = ["auto_handle", "auto_handle", "escalate_to_human"]
    res = compute_escalation_metrics(y_true, y_pred)
    assert res["false_auto_handle_count"] == 1
    assert res["false_auto_handle_rate"] == 0.5


def test_rouge_and_bleu():
    ref = "Try restarting your phone and check Settings > General > About"
    hyp = "Please restart your phone and check Settings > General > About"
    rouge = calculate_rouge_l(ref, hyp)
    bleu = calculate_bleu(ref, hyp)
    assert rouge > 0.7
    assert bleu > 0.5


def test_judge_rubric_evaluation():
    judge = LLMJudgeRubric()
    evaluation = judge.evaluate(
        customer_text="How do I take a screenshot on iPhone X?",
        generated_reply="Press Volume Up and Side button simultaneously. A preview will appear.",
        reference_reply="Press Side button and Volume Up simultaneously.",
        intent="device_setup_how_to",
        escalation_decision="auto_handle"
    )
    assert 1 <= evaluation.groundedness_score <= 5
    assert 1 <= evaluation.actionability_score <= 5
    assert 1 <= evaluation.brand_tone_score <= 5
    assert 1 <= evaluation.safety_soundness_score <= 5
    assert 1.0 <= evaluation.composite_score <= 5.0
    assert evaluation.verdict in ["ACCEPTABLE", "NEEDS_REVISION", "CRITICAL_DEFECT"]
