"""
Extracts and curates a real-world AppleSupport knowledge base from the Twitter Customer Support dataset.
Streams a targeted slice from HuggingFace to avoid downloading the entire 517MB CSV.
"""
import csv
import html
import io
import json
import os
import re
import sys
import urllib.request

sys.stdout.reconfigure(encoding='utf-8')

TWCS_STREAM_URL = "https://huggingface.co/datasets/SunidhiSriram/twcs/resolve/main/twcs.csv"
OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "historical_knowledge_base.jsonl")


def clean_text(text: str) -> str:
    """Cleans tweet text by unescaping HTML and normalizing whitespace."""
    if not text:
        return ""
    text = html.unescape(text)
    # Remove leading @mentions
    text = re.sub(r"^(@\w+\s*)+", "", text)
    # Normalize whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text


def fetch_and_build_kb(target_pairs: int = 2500, byte_range_mb: int = 20):
    print(f"Fetching {byte_range_mb}MB slice from {TWCS_STREAM_URL}...")
    headers = {
        "Range": f"bytes=0-{byte_range_mb * 1024 * 1024}",
        "User-Agent": "Mozilla/5.0 (Hiver-SDE-Assignment-Extractor)"
    }
    req = urllib.request.Request(TWCS_STREAM_URL, headers=headers)
    
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            raw_data = resp.read().decode("utf-8", errors="ignore")
    except Exception as e:
        print(f"Error streaming from remote: {e}")
        return False

    # Drop the trailing partial line
    clean_csv = raw_data.rsplit("\n", 1)[0]
    reader = csv.DictReader(io.StringIO(clean_csv))
    rows = list(reader)
    print(f"Parsed {len(rows)} raw tweets from slice.")

    # Index tweets by ID
    id_to_tweet = {r["tweet_id"]: r for r in rows if "tweet_id" in r}
    
    pairs = []
    seen_queries = set()

    for row in rows:
        if row.get("author_id") == "AppleSupport":
            in_resp_id = row.get("in_response_to_tweet_id")
            if in_resp_id and in_resp_id in id_to_tweet:
                cust_tweet = id_to_tweet[in_resp_id]
                cust_text = clean_text(cust_tweet.get("text", ""))
                agent_text = clean_text(row.get("text", ""))

                # Filter out trivial, empty, or duplicate queries
                if len(cust_text) < 15 or len(agent_text) < 15:
                    continue
                if cust_text.lower() in seen_queries:
                    continue

                seen_queries.add(cust_text.lower())
                pairs.append({
                    "id": f"apple_kb_{len(pairs) + 1}",
                    "customer_tweet_id": cust_tweet.get("tweet_id"),
                    "support_tweet_id": row.get("tweet_id"),
                    "customer_query": cust_text,
                    "support_resolution": agent_text,
                    "created_at": row.get("created_at")
                })

                if len(pairs) >= target_pairs:
                    break

    print(f"Extracted {len(pairs)} unique, high-quality AppleSupport Q&A pairs.")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for p in pairs:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")

    print(f"Successfully saved knowledge base to {OUTPUT_FILE}")
    return True


if __name__ == "__main__":
    fetch_and_build_kb(target_pairs=2500, byte_range_mb=20)
