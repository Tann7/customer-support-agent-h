# Golden Evaluation Set: Sampling & Labeling Methodology

## 1. Overview
The Golden Evaluation Set comprises **200 hand-curated and rigorously labeled customer queries** targeting `@AppleSupport` from the Twitter Customer Support corpus (`thoughtvector/customer-support-on-twitter`).

## 2. Intent Taxonomy & Distribution
The dataset covers 6 grounded customer support intents reflecting real Apple customer needs:
- `software_os_issue` (45 examples, ~22.5%): iOS update glitches, app crashes, keyboard bugs, freezing, restore errors.
- `battery_power_hardware` (40 examples, 20.0%): Battery health degradation, rapid draining, thermal warnings, charging port issues, and physical damage.
- `connectivity_sync` (35 examples, 17.5%): Wi-Fi disconnects, Bluetooth dropouts, AirPods audio cuts, AirDrop failures, iCloud sync pauses.
- `account_billing_subscription` (35 examples, 17.5%): Apple ID lockouts, two-factor recovery, recurring subscriptions, unauthorized charges.
- `device_setup_how_to` (25 examples, 12.5%): Quick Start migration, screenshot gestures, Apple Pay setup, accessibility options.
- `complaint_feedback` (20 examples, 10.0%): Hardware criticism (headphone jack), update frustration, support escalation demands.

## 3. Escalation Ground Truth Policy
Each example is labeled with a binary decision:
- `auto_handle`: Safe for automated self-service resolution. Problems with standard diagnostic paths, settings navigation, or software workarounds.
- `escalate_to_human`: Must be routed to a human specialist. Categories include:
  - `pii_account_security`: Apple ID compromised, security questions forgotten, recovery loops.
  - `financial_dispute`: Unauthorized billing, double charges, refund requests.
  - `hardware_safety_hazard`: Swollen battery, burning smell, shattered glass with injury.
  - `dissatisfaction_or_legal`: Severe customer distress, multiple failed service interactions, legal threats.
  - `complex_unresolved`: Unresolved hardware failures (grayed Wi-Fi chip, Face ID hardware error, iTunes 4013).

## 4. Sampling Strategy
1. **Diversity of Difficulty**: 60% standard unambiguous queries, 25% ambiguous/multi-symptom queries, 15% adversarial/extreme queries (safety hazards, legal threats, sarcasm).
2. **Real Twitter Noise**: Authentic user slang, typos, emotional intensity, and missing context to mirror production conditions.
3. **Double Verification**: Each example was checked against Apple's official support documentation and guidelines to ensure factual validity.
