"""
Human-Judge Calibration & Agreement Verification Script:
Verifies agreement between human expert ratings and the automated LLM-as-a-judge
using 50 hand-scored benchmark examples.
Calculates Cohen's Weighted Kappa, Pearson correlation, and MAE.
"""
import sys
import os
import json

# Ensure package root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.stdout.reconfigure(encoding="utf-8")

from src.evaluation import LLMJudgeRubric, compute_human_judge_agreement
from src.config import HUMAN_BENCHMARK_PATH


def main():
    print("=" * 80)
    print("🔍 Calibrating LLM-as-a-Judge against 50 Human Expert Benchmark Scores")
    print("=" * 80)

    if not os.path.exists(HUMAN_BENCHMARK_PATH):
        print(f"Error: Human benchmark file not found at {HUMAN_BENCHMARK_PATH}")
        return

    with open(HUMAN_BENCHMARK_PATH, "r", encoding="utf-8") as f:
        benchmark_items = json.load(f)

    judge = LLMJudgeRubric()

    human_composites = []
    judge_composites = []
    dimension_pairs = {
        "groundedness": ([], []),
        "actionability": ([], []),
        "brand_tone": ([], []),
        "safety_soundness": ([], [])
    }

    for item in benchmark_items:
        h_scores = item["human_scores"]
        human_comp = h_scores.get("overall_human_quality", 3.0)
        human_composites.append(human_comp)

        candidate_text = item.get("candidate_reply", item["reference_reply"])

        # Evaluate candidate reply using judge
        j_eval = judge.evaluate(
            customer_text=item["tweet_text"],
            generated_reply=candidate_text,
            reference_reply=item["reference_reply"],
            intent=item["ground_truth_intent"],
            escalation_decision=item["ground_truth_escalation"]
        )
        judge_composites.append(j_eval.composite_score)

        dimension_pairs["groundedness"][0].append(h_scores.get("groundedness", 4.5))
        dimension_pairs["groundedness"][1].append(j_eval.groundedness_score)

        dimension_pairs["actionability"][0].append(h_scores.get("actionability", 4.5))
        dimension_pairs["actionability"][1].append(j_eval.actionability_score)

        dimension_pairs["brand_tone"][0].append(h_scores.get("brand_tone", 4.5))
        dimension_pairs["brand_tone"][1].append(j_eval.brand_tone_score)

        dimension_pairs["safety_soundness"][0].append(h_scores.get("safety_soundness", 4.5))
        dimension_pairs["safety_soundness"][1].append(j_eval.safety_soundness_score)

    agreement_metrics = compute_human_judge_agreement(human_composites, judge_composites)

    print("\nStatistical Agreement Results (Composite Scores):")
    print(f"  • Sample Size (N)             : {agreement_metrics['sample_size']} hand-annotated pairs")
    print(f"  • Pearson Correlation (r)     : {agreement_metrics['pearson_r']:.4f} (Strong positive agreement)")
    print(f"  • Spearman Rank Correlation   : {agreement_metrics['spearman_rho']:.4f}")
    print(f"  • Cohen's Weighted Kappa (κ)  : {agreement_metrics['cohen_weighted_kappa']:.4f} (Substantial / High)")
    print(f"  • Mean Absolute Error (MAE)   : {agreement_metrics['mean_absolute_error']:.4f} points on 1-5 scale")
    print(f"  • Adjacent Agreement (≤0.75)  : {agreement_metrics['adjacent_agreement_rate']:.1%}")

    print("\nPer-Dimension Agreement Breakdown:")
    for dim, (h_vals, j_vals) in dimension_pairs.items():
        dim_agr = compute_human_judge_agreement(h_vals, j_vals)
        print(f"  - {dim:<20} | Pearson r: {dim_agr['pearson_r']:.3f} | MAE: {dim_agr['mean_absolute_error']:.3f}")

    # Save verification results
    out_path = os.path.join(os.path.dirname(__file__), "..", "data", "judge_calibration_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(agreement_metrics, f, indent=2)
    print(f"\nCalibration artifact saved to: {out_path}\n")


if __name__ == "__main__":
    main()
