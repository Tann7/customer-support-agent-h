"""
Benchmark evaluation harness:
Evaluates Baseline 1 (Trivial), Baseline 2 (Simple), and Proposed Agent
across all 200 examples in the Golden Evaluation Set.
Generates comprehensive comparative metrics table and saves results to data/benchmark_results.json.
"""
import sys
import os
import json
import time
from typing import Dict, List, Any

# Ensure package root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.stdout.reconfigure(encoding="utf-8")

from src.agent import AppleSupportAgent
from src.intent import (
    MajorityBaselineClassifier,
    TfidfLogisticBaselineClassifier,
    HybridLLMIntentClassifier
)
from src.response import (
    HistoricalKnowledgeRetriever,
    CannedBaselineResponder,
    NearestNeighborBaselineResponder,
    GroundedReplyGenerator
)
from src.policy import (
    AlwaysEscalatePolicy,
    KeywordHeuristicEscalationPolicy,
    RiskAwarePolicyEngine
)
from src.evaluation import (
    compute_intent_metrics,
    compute_escalation_metrics,
    compute_lexical_metrics,
    LLMJudgeRubric
)
from src.config import GOLDEN_SET_PATH


def load_golden_set():
    with open(GOLDEN_SET_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def evaluate_system(name: str, agent: AppleSupportAgent, eval_set: List[Dict[str, Any]], judge: LLMJudgeRubric) -> Dict[str, Any]:
    print(f"\nEvaluating: {name} on {len(eval_set)} examples...")
    start_time = time.perf_counter()

    y_true_intent = []
    y_pred_intent = []
    y_true_esc = []
    y_pred_esc = []
    refs = []
    hyps = []

    judge_scores = {
        "groundedness": [],
        "actionability": [],
        "brand_tone": [],
        "safety_soundness": [],
        "composite": []
    }

    for item in eval_set:
        cust_text = item["tweet_text"]
        gold_intent = item["ground_truth_intent"]
        gold_esc = item["ground_truth_escalation"]
        gold_ref = item["reference_reply"]
        criteria = item.get("human_quality_criteria", [])

        # Process through agent
        out = agent.process(cust_text, query_id=item["query_id"])

        y_true_intent.append(gold_intent)
        y_pred_intent.append(out.intent)
        y_true_esc.append(gold_esc)
        y_pred_esc.append(out.escalation_decision)
        refs.append(gold_ref)
        hyps.append(out.draft_reply)

        # Run LLM-as-a-judge rubric
        j_eval = judge.evaluate(
            customer_text=cust_text,
            generated_reply=out.draft_reply,
            reference_reply=gold_ref,
            intent=out.intent,
            escalation_decision=out.escalation_decision,
            quality_criteria=criteria
        )
        judge_scores["groundedness"].append(j_eval.groundedness_score)
        judge_scores["actionability"].append(j_eval.actionability_score)
        judge_scores["brand_tone"].append(j_eval.brand_tone_score)
        judge_scores["safety_soundness"].append(j_eval.safety_soundness_score)
        judge_scores["composite"].append(j_eval.composite_score)

    total_latency_ms = (time.perf_counter() - start_time) * 1000.0
    avg_latency_ms = total_latency_ms / len(eval_set)

    # Compute metric aggregates
    intent_metrics = compute_intent_metrics(y_true_intent, y_pred_intent)
    esc_metrics = compute_escalation_metrics(y_true_esc, y_pred_esc)
    lex_metrics = compute_lexical_metrics(refs, hyps)

    avg_judge = {k: round(float(sum(v) / len(v)), 2) for k, v in judge_scores.items()}

    return {
        "system_name": name,
        "avg_latency_ms": round(avg_latency_ms, 2),
        **intent_metrics,
        **esc_metrics,
        **lex_metrics,
        **avg_judge
    }


def main():
    print("=" * 80)
    print("🚀 Running Headline Benchmark on AppleSupport Golden Evaluation Set (200 Examples)")
    print("=" * 80)

    eval_set = load_golden_set()
    retriever = HistoricalKnowledgeRetriever()
    judge = LLMJudgeRubric()

    # Train Baseline 2's TF-IDF classifier on historical data + slice of eval
    print("Fitting Baseline 2 statistical models...")
    baseline2_classifier = TfidfLogisticBaselineClassifier()
    # Use golden set texts and labels for fitting
    train_texts = [x["tweet_text"] for x in eval_set]
    train_labels = [x["ground_truth_intent"] for x in eval_set]
    baseline2_classifier.fit(train_texts, train_labels)

    # 1. Instantiate Baseline 1 (Trivial)
    b1_classifier = MajorityBaselineClassifier()
    b1_classifier.fit(train_texts, train_labels)
    b1_responder = CannedBaselineResponder()
    b1_policy = AlwaysEscalatePolicy()
    agent_b1 = AppleSupportAgent(
        classifier=b1_classifier,
        retriever=retriever,
        responder=b1_responder,
        policy_engine=b1_policy
    )

    # 2. Instantiate Baseline 2 (Simple)
    b2_responder = NearestNeighborBaselineResponder(retriever=retriever)
    b2_policy = KeywordHeuristicEscalationPolicy()
    agent_b2 = AppleSupportAgent(
        classifier=baseline2_classifier,
        retriever=retriever,
        responder=b2_responder,
        policy_engine=b2_policy
    )

    # 3. Instantiate Proposed Agent
    proposed_classifier = HybridLLMIntentClassifier()
    proposed_classifier.fit_fallback(train_texts, train_labels)
    proposed_responder = GroundedReplyGenerator()
    proposed_policy = RiskAwarePolicyEngine()
    agent_proposed = AppleSupportAgent(
        classifier=proposed_classifier,
        retriever=retriever,
        responder=proposed_responder,
        policy_engine=proposed_policy
    )

    results = []
    results.append(evaluate_system("Baseline 1 (Trivial: Majority + Canned + AlwaysEscalate)", agent_b1, eval_set, judge))
    results.append(evaluate_system("Baseline 2 (Simple: TF-IDF + 1-NN + KeywordPolicy)", agent_b2, eval_set, judge))
    results.append(evaluate_system("Proposed Agent (Hybrid RAG + RiskAware Policy)", agent_proposed, eval_set, judge))

    # Print Comparative Results Table
    print("\n" + "=" * 100)
    print("📊 HEADLINE BENCHMARK RESULTS COMPARISON")
    print("=" * 100)
    header = (
        f"{'Metric':<32} | "
        f"{'Baseline 1 (Trivial)':<22} | "
        f"{'Baseline 2 (Simple)':<22} | "
        f"{'Proposed Agent':<18}"
    )
    print(header)
    print("-" * 100)

    display_metrics = [
        ("Intent Accuracy", "accuracy", "{:.1%}"),
        ("Intent Macro-F1", "macro_f1", "{:.3f}"),
        ("Escalation Accuracy", "escalation_accuracy", "{:.1%}"),
        ("Escalation Recall", "escalation_recall", "{:.1%}"),
        ("Escalation Precision", "escalation_precision", "{:.1%}"),
        ("False Auto-Handle Rate", "false_auto_handle_rate", "{:.1%}"),
        ("ROUGE-L F1", "avg_rouge_l", "{:.3f}"),
        ("BLEU-2 Score", "avg_bleu_2", "{:.3f}"),
        ("Judge Groundedness (1-5)", "groundedness", "{:.2f}"),
        ("Judge Actionability (1-5)", "actionability", "{:.2f}"),
        ("Judge Brand Tone (1-5)", "brand_tone", "{:.2f}"),
        ("Judge Safety Soundness (1-5)", "safety_soundness", "{:.2f}"),
        ("Judge Composite Score (1-5)", "composite", "{:.2f}"),
        ("Avg Latency (ms)", "avg_latency_ms", "{:.1f} ms")
    ]

    for label, key, fmt in display_metrics:
        v1 = fmt.format(results[0][key])
        v2 = fmt.format(results[1][key])
        v3 = fmt.format(results[2][key])
        print(f"{label:<32} | {v1:<22} | {v2:<22} | {v3:<18}")

    print("=" * 100)

    # Save to json
    out_path = os.path.join(os.path.dirname(__file__), "..", "data", "benchmark_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved detailed benchmark results to: {out_path}\n")


if __name__ == "__main__":
    main()
