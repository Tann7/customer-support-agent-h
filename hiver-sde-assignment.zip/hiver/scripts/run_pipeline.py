"""
Interactive & batch CLI runner for testing the AppleSupport AI Agent.
"""
import sys
import os
import argparse

# Ensure package root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.stdout.reconfigure(encoding="utf-8")

from src.agent import AppleSupportAgent


def main():
    parser = argparse.ArgumentParser(description="AppleSupport AI Support Agent Pipeline")
    parser.add_argument("--demo", action="store_true", help="Run sample demonstration queries and exit")
    parser.add_argument("--query", type=str, help="Process a single query and output structured result")
    parser.add_argument("--interactive", action="store_true", help="Run in interactive prompt mode")
    args = parser.parse_args()

    print("=" * 80)
    print("🍎 AppleSupport AI Support Agent Pipeline")
    print("=" * 80)
    agent = AppleSupportAgent()

    if args.query:
        out = agent.process(args.query)
        print(f"Customer Tweet : \"{args.query}\"")
        print(f"Intent         : {out.intent} ({out.intent_confidence:.1%})")
        print(f"Decision       : {out.escalation_decision.upper()} [{out.escalation_category}]")
        print(f"Reason         : {out.escalation_reason}")
        print(f"Reply          : {out.draft_reply}")
        print(f"Latency        : {out.latency_ms:.1f} ms")
        return

    # Default to demo if not explicitly interactive
    sample_queries = [
        "My battery is draining from 100% to 20% in two hours after updating to iOS 11.1!",
        "My iPhone charger sparked and now the phone battery is swollen pushing the screen off!",
        "Someone hacked into my Apple ID and changed my recovery phone number. I'm locked out.",
        "How do I cancel my Apple Music subscription before the free trial renews?",
        "How do I take a screenshot on the new iPhone X without a home button?",
        "Your new updates are complete garbage and ruined my phone, I am suing Apple!"
    ]

    print("Running sample demonstration queries across different intent categories:\n")
    for i, q in enumerate(sample_queries, 1):
        print(f"[{i}] Customer Tweet: \"{q}\"")
        output = agent.process(q)
        print(f"   ├─ Classified Intent : {output.intent} (Confidence: {output.intent_confidence:.1%})")
        print(f"   ├─ Policy Decision   : {output.escalation_decision.upper()} [{output.escalation_category}]")
        print(f"   ├─ Escalation Reason : {output.escalation_reason}")
        print(f"   ├─ Drafted Reply     : {output.draft_reply}")
        print(f"   └─ Latency           : {output.latency_ms:.1f} ms\n")

    if args.interactive:
        print("=" * 80)
        print("Entering interactive mode. Type your query or press Ctrl+C to exit:")
        try:
            while True:
                user_input = input("\nEnter customer tweet > ").strip()
                if not user_input:
                    break
                out = agent.process(user_input)
                print(f"-> Intent   : {out.intent} ({out.intent_confidence:.1%})")
                print(f"-> Decision : {out.escalation_decision.upper()} ({out.escalation_category})")
                print(f"-> Reason   : {out.escalation_reason}")
                print(f"-> Reply    : {out.draft_reply}")
                print(f"-> Latency  : {out.latency_ms:.1f} ms")
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive mode.")


if __name__ == "__main__":
    main()
