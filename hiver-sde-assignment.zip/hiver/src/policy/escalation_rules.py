"""
Risk rules and pattern detectors for safe auto-handling vs. human escalation.
"""
import re
from typing import Dict, List, Tuple, Any
from ..models import EscalationReasonCategory

RISK_TRIGGERS: Dict[EscalationReasonCategory, Dict[str, Any]] = {
    "hardware_safety_hazard": {
        "keywords": [
            "swelling", "swollen", "smoke", "spark", "sparked", "burning", 
            "fire", "exploded", "melted", "shock", "cut my finger", "shards", "blew up"
        ],
        "reason": "Immediate safety or physical hardware risk requiring urgent specialized handling."
    },
    "pii_account_security": {
        "keywords": [
            "hacked", "stolen", "compromised", "apple id locked", "locked apple id", 
            "recovery phone", "account recovery", "unauthorized access", "someone changed my password",
            "security questions", "locked for security reasons"
        ],
        "reason": "Account credentials or private identity verification required in confidential channel."
    },
    "financial_dispute": {
        "keywords": [
            "unauthorized charge", "unrecognized charge", "charged twice", "double billed", 
            "duplicate charge", "unauthorized purchase", "want a refund", "need a refund", 
            "refund my money", "chargeback", "dispute charge", "bank"
        ],
        "reason": "Financial transaction review or refund processing requires authorized billing specialist."
    },
    "dissatisfaction_or_legal": {
        "keywords": [
            "lawyer", "attorney", "lawsuit", "sue", "suing", "sued", "court",
            "consumer court", "better business bureau", "bbb", "legal action",
            "hung up on me", "worst customer support", "threat", "fraud", "scam"
        ],
        "reason": "Severe escalation trigger, legal threat, or repeated customer service breakdown."
    },
    "complex_unresolved": {
        "keywords": [
            "error 4013", "error 9", "bootloop", "grayed out", "truedepth", "hardware diagnostic",
            "visited genius bar three times", "third time replacing", "logic board"
        ],
        "reason": "Deep hardware or recurring unresolved technical failure requiring senior diagnostic advisor."
    }
}


def evaluate_risk_rules(text: str) -> Tuple[bool, EscalationReasonCategory, str, List[str]]:
    """
    Evaluates text against high-risk safety patterns.
    Returns: (is_triggered, category, reason, matched_keywords)
    """
    lower_text = text.lower()

    for category, meta in RISK_TRIGGERS.items():
        matched = []
        for kw in meta["keywords"]:
            if kw in lower_text:
                matched.append(kw)
        if matched:
            return True, category, meta["reason"], matched

    return False, "none", "", []
