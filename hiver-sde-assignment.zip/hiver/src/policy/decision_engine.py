"""
Policy decision engines for determining auto-handle vs. human escalation:
1. AlwaysEscalatePolicy (Trivial Baseline): Always escalates to human.
2. KeywordHeuristicEscalationPolicy (Simple Baseline): Escalates based on naive keyword matches.
3. RiskAwarePolicyEngine (Proposed Agent): Multi-factor safety matrix with confidence gating.
"""
from typing import List, Optional
from ..models import EscalationDecision, IntentResult, IntentType
from ..config import CONFIDENCE_THRESHOLD
from .escalation_rules import evaluate_risk_rules, RISK_TRIGGERS


class AlwaysEscalatePolicy:
    """Trivial Baseline: Conservative policy that always escalates everything to human."""
    def decide(self, text: str, intent_res: IntentResult) -> EscalationDecision:
        return EscalationDecision(
            decision="escalate_to_human",
            category="complex_unresolved",
            reason="Always-escalate baseline policy enforced.",
            safety_triggers=["baseline_default"]
        )


class KeywordHeuristicEscalationPolicy:
    """Simple Baseline: Escalates if any common sensitive keyword appears."""
    def __init__(self, keywords: Optional[List[str]] = None):
        self.keywords = keywords or ["refund", "hacked", "stolen", "locked", "lawyer", "swollen", "fire"]

    def decide(self, text: str, intent_res: IntentResult) -> EscalationDecision:
        lower = text.lower()
        matched = [k for k in self.keywords if k in lower]
        if matched:
            return EscalationDecision(
                decision="escalate_to_human",
                category="financial_dispute" if "refund" in matched else "pii_account_security",
                reason=f"Matched sensitive escalation keyword(s): {', '.join(matched)}",
                safety_triggers=matched
            )
        return EscalationDecision(
            decision="auto_handle",
            category="none",
            reason="No sensitive escalation keywords detected.",
            safety_triggers=[]
        )


class RiskAwarePolicyEngine:
    """
    Production / Proposed Policy Engine:
    Combines domain risk rule evaluation, confidence threshold gating,
    and structured justification generation.
    """
    def __init__(self, confidence_cutoff: float = CONFIDENCE_THRESHOLD):
        self.confidence_cutoff = confidence_cutoff

    def decide(self, text: str, intent_res: IntentResult) -> EscalationDecision:
        # 1. Evaluate explicit safety and security risk rules
        triggered, category, reason, matched_kw = evaluate_risk_rules(text)
        if triggered:
            return EscalationDecision(
                decision="escalate_to_human",
                category=category,
                reason=reason,
                safety_triggers=matched_kw
            )

        # 2. Evaluate model confidence threshold gating
        if intent_res.confidence < self.confidence_cutoff:
            return EscalationDecision(
                decision="escalate_to_human",
                category="low_model_confidence",
                reason=(
                    f"Model confidence ({intent_res.confidence:.1%}) is below safety threshold "
                    f"({self.confidence_cutoff:.1%}). Routing to human to prevent misguidance."
                ),
                safety_triggers=[f"low_conf_{intent_res.confidence:.2f}"]
            )

        # 3. Intent-specific policy constraints
        # Account billing inquiries demanding refunds or modifications should never be auto-closed
        if intent_res.intent == "account_billing_subscription" and any(w in text.lower() for w in ["charge", "billed", "bill", "money"]):
            return EscalationDecision(
                decision="escalate_to_human",
                category="financial_dispute",
                reason="Billing discrepancies require authorized agent review.",
                safety_triggers=["billing_discrepancy"]
            )

        # 4. Safe for automated handling
        return EscalationDecision(
            decision="auto_handle",
            category="none",
            reason=(
                f"Classified as '{intent_res.intent}' with high confidence ({intent_res.confidence:.1%}) "
                "and no critical safety or security triggers detected."
            ),
            safety_triggers=[]
        )
