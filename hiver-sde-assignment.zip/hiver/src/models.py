"""
Pydantic models for structured type safety across the AppleSupport Agent pipeline.
"""
from typing import List, Optional, Dict, Any, Literal
from pydantic import BaseModel, Field


IntentType = Literal[
    "software_os_issue",
    "battery_power_hardware",
    "connectivity_sync",
    "account_billing_subscription",
    "device_setup_how_to",
    "complaint_feedback"
]

EscalationDecisionType = Literal["auto_handle", "escalate_to_human"]

EscalationReasonCategory = Literal[
    "none",
    "pii_account_security",
    "financial_dispute",
    "hardware_safety_hazard",
    "dissatisfaction_or_legal",
    "low_model_confidence",
    "complex_unresolved"
]


class CustomerTweet(BaseModel):
    query_id: Optional[str] = None
    text: str
    inbound_timestamp: Optional[str] = None


class IntentResult(BaseModel):
    intent: IntentType
    confidence: float = Field(ge=0.0, le=1.0)
    explanation: Optional[str] = None


class RetrievedContext(BaseModel):
    id: str
    customer_query: str
    support_resolution: str
    relevance_score: float


class EscalationDecision(BaseModel):
    decision: EscalationDecisionType
    category: EscalationReasonCategory
    reason: str
    safety_triggers: List[str] = Field(default_factory=list)


class SupportAgentOutput(BaseModel):
    query_id: Optional[str] = None
    customer_text: str
    intent: IntentType
    intent_confidence: float
    retrieved_contexts: List[RetrievedContext] = Field(default_factory=list)
    draft_reply: str
    escalation_decision: EscalationDecisionType
    escalation_category: EscalationReasonCategory
    escalation_reason: str
    latency_ms: float = 0.0


class JudgeEvaluation(BaseModel):
    groundedness_score: int = Field(ge=1, le=5)
    actionability_score: int = Field(ge=1, le=5)
    brand_tone_score: int = Field(ge=1, le=5)
    safety_soundness_score: int = Field(ge=1, le=5)
    composite_score: float = Field(ge=1.0, le=5.0)
    verdict: Literal["ACCEPTABLE", "NEEDS_REVISION", "CRITICAL_DEFECT"]
    critique: str
