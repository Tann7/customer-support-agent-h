"""
Configuration settings, path definitions, and policy thresholds for the AppleSupport Agent.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

# Data file paths
HISTORICAL_KB_PATH = DATA_DIR / "historical_knowledge_base.jsonl"
GOLDEN_SET_PATH = DATA_DIR / "golden_eval_set.json"
HUMAN_BENCHMARK_PATH = DATA_DIR / "human_judge_benchmark.json"

# Operational thresholds
CONFIDENCE_THRESHOLD = 0.65  # Below this, agent routes to human for safety
MAX_TWEET_LENGTH = 280       # Twitter constraint
TOP_K_RETRIEVAL = 3          # Historical precedents to retrieve for RAG

# Model configuration
DEFAULT_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")
FALLBACK_DM_URL = "https://apple.co/DM"
FALLBACK_FEEDBACK_URL = "https://apple.co/Feedback"
REPORT_PROBLEM_URL = "https://reportaproblem.apple.com"
IFORGOT_URL = "https://iforgot.apple.com"
