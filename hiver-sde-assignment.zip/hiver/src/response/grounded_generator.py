"""
Production / Proposed Grounded Reply Generator:
Synthesizes empathetic, brand-aligned AppleSupport responses grounded in historical solutions
and official support documentation, respecting Twitter character constraints (<280 chars).
"""
import os
import re
from typing import List, Optional
from ..models import RetrievedContext, IntentType
from ..config import (
    MAX_TWEET_LENGTH,
    FALLBACK_DM_URL,
    FALLBACK_FEEDBACK_URL,
    REPORT_PROBLEM_URL,
    IFORGOT_URL
)


class GroundedReplyGenerator:
    """
    RAG Response Generator that produces grounded, empathetic Twitter replies.
    Supports live LLM synthesis via standard LLM APIs when configured, with a high-fidelity,
    grounded heuristic template synthesizer for fast offline reproduction.
    """
    def __init__(self):
        pass

    def generate(
        self,
        customer_text: str,
        intent: IntentType,
        contexts: List[RetrievedContext],
        is_escalated: bool = False,
        escalation_reason: str = ""
    ) -> str:
        # Check if live LLM is enabled
        llm_key = os.getenv("LLM_API_KEY") or os.getenv("OPENAI_API_KEY")
        if llm_key:
            try:
                return self._generate_llm(customer_text, intent, contexts, is_escalated, escalation_reason, llm_key)
            except Exception:
                pass

        return self._generate_grounded_heuristic(customer_text, intent, contexts, is_escalated, escalation_reason)

    def _generate_grounded_heuristic(
        self,
        customer_text: str,
        intent: IntentType,
        contexts: List[RetrievedContext],
        is_escalated: bool,
        escalation_reason: str
    ) -> str:
        lower_q = customer_text.lower()

        # 1. Critical safety hazard overrides
        if "swollen" in lower_q or "swelling" in lower_q or "smoke" in lower_q or "spark" in lower_q:
            reply = (
                "For your safety, please stop using and do not charge the device. "
                f"Meet us in DM immediately so we can urgently assist: {FALLBACK_DM_URL}"
            )
            return self._enforce_constraints(reply)

        # 2. Account compromise / security overrides
        if "hacked" in lower_q or "locked" in lower_q or "apple id" in lower_q and is_escalated:
            reply = (
                f"We take security seriously. Please visit {IFORGOT_URL} to start account recovery, "
                f"and connect with us in DM so we can safely guide you: {FALLBACK_DM_URL}"
            )
            return self._enforce_constraints(reply)

        # 3. Billing & Refund disputes
        if intent == "account_billing_subscription" and ("charge" in lower_q or "refund" in lower_q or "billed" in lower_q):
            reply = (
                f"To inspect your charges or request a refund securely, visit {REPORT_PROBLEM_URL}. "
                f"Send us a DM if you need help with your invoices: {FALLBACK_DM_URL}"
            )
            return self._enforce_constraints(reply)

        # 4. Feedback & venting
        if intent == "complaint_feedback":
            if is_escalated:
                reply = (
                    "We deeply regret this experience and want to make it right. "
                    f"Please DM us your case details so a manager can review: {FALLBACK_DM_URL}"
                )
            else:
                reply = (
                    "We appreciate you sharing your thoughts with us. "
                    f"You can submit feedback directly to our product teams here: {FALLBACK_FEEDBACK_URL}"
                )
            return self._enforce_constraints(reply)

        # 5. Software / OS specific groundings
        if intent == "software_os_issue":
            if "keyboard" in lower_q or "autocorrect" in lower_q or "letter" in lower_q:
                reply = (
                    "We understand how frustrating that is! Go to Settings > General > Keyboard > "
                    "Text Replacement and set a temporary shortcut. A permanent fix is in the next update."
                )
                return self._enforce_constraints(reply)
            if "frozen" in lower_q or "logo" in lower_q or "stuck" in lower_q:
                reply = (
                    "Let's get this resolved! Try a force restart: quickly press Volume Up, Volume Down, "
                    "then hold the Side button until the Apple logo appears."
                )
                return self._enforce_constraints(reply)

        # 6. Battery / hardware groundings
        if intent == "battery_power_hardware":
            if "health" in lower_q or "drain" in lower_q or "percentage" in lower_q:
                reply = (
                    "We'd love to help with your battery. Check your Maximum Capacity under Settings > "
                    "Battery > Battery Health to review your chemical condition."
                )
                return self._enforce_constraints(reply)

        # 7. Connectivity groundings
        if intent == "connectivity_sync":
            if "airdrop" in lower_q:
                reply = (
                    "Let's get AirDrop working! Check Finder > AirDrop and ensure 'Allow me to be discovered by' "
                    "is set to 'Everyone'. Also verify Wi-Fi and Bluetooth are active."
                )
                return self._enforce_constraints(reply)
            if "airpods" in lower_q:
                reply = (
                    "We want your AirPods working smoothly. Go to Settings > Bluetooth > tap 'i' next to "
                    "AirPods > Microphone, and try setting it to Left or Right."
                )
                return self._enforce_constraints(reply)

        # 8. RAG synthesis from top retrieved context
        if contexts and contexts[0].relevance_score > 0.20:
            top_res = contexts[0].support_resolution
            # Clean and adapt
            cleaned = re.sub(r"^(@\w+\s*)+", "", top_res).strip()
            if not cleaned.endswith((".", "!", "?")):
                cleaned += "."
            if is_escalated and "DM" not in cleaned:
                cleaned += f" Reach us in DM here: {FALLBACK_DM_URL}"
            return self._enforce_constraints(cleaned)

        # Generic safe brand fallback
        if is_escalated:
            reply = f"We'd like to look into this with you. Please send us a DM so we can assist further: {FALLBACK_DM_URL}"
        else:
            reply = "We're here to help! Which iOS version and device model are you using? You can check in Settings > General > About."
        
        return self._enforce_constraints(reply)

    def _generate_llm(
        self,
        customer_text: str,
        intent: IntentType,
        contexts: List[RetrievedContext],
        is_escalated: bool,
        escalation_reason: str,
        api_key: str
    ) -> str:
        import json
        import urllib.request
        context_str = "\n".join([f"- Prior Case: {c.customer_query} -> {c.support_resolution}" for c in contexts[:2]])
        prompt = f"""You are the official @AppleSupport Twitter account.
Draft a concise, polite, helpful tweet response (<280 chars) to this customer:
Customer Tweet: "{customer_text}"
Intent: {intent}
Escalated to Human: {is_escalated} (Reason: {escalation_reason})

Grounded Knowledge from historical Apple support resolutions:
{context_str}

Guidelines:
- Empathetic and professional tone.
- Exact settings navigation if applicable (e.g. Settings > General > About).
- NEVER promise free replacements or store credits.
- Under 280 characters strictly.
"""
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        payload = json.dumps({
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 150
        }).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            reply_text = data["choices"][0]["message"]["content"]
        return self._enforce_constraints(reply_text.strip())

    def _enforce_constraints(self, text: str) -> str:
        """Ensures text fits Twitter limits and is clean."""
        text = re.sub(r"\s+", " ", text).strip()
        if len(text) <= MAX_TWEET_LENGTH:
            return text
        # Truncate cleanly at word boundary
        truncated = text[:MAX_TWEET_LENGTH - 4].rsplit(" ", 1)[0] + "..."
        return truncated
