"""
Retrieval engine indexing real historical AppleSupport interactions
for grounded Few-Shot / RAG generation.
"""
import json
import os
from typing import List, Optional
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from ..models import RetrievedContext
from ..config import HISTORICAL_KB_PATH, TOP_K_RETRIEVAL


class HistoricalKnowledgeRetriever:
    """
    Indexes historical AppleSupport Q&A pairs and retrieves the most relevant
    prior cases given an incoming customer message.
    """
    def __init__(self, kb_path: Optional[str] = None):
        self.kb_path = kb_path or str(HISTORICAL_KB_PATH)
        self.records = []
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            max_features=10000,
            sublinear_tf=True,
            stop_words="english"
        )
        self.doc_matrix = None
        self._load_and_index()

    def _load_and_index(self):
        if not os.path.exists(self.kb_path):
            raise FileNotFoundError(f"Knowledge base not found at {self.kb_path}")

        with open(self.kb_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    self.records.append(json.loads(line))

        if not self.records:
            raise ValueError("Knowledge base file is empty.")

        corpus = [r["customer_query"] for r in self.records]
        self.doc_matrix = self.vectorizer.fit_transform(corpus)

    def retrieve(self, query: str, top_k: int = TOP_K_RETRIEVAL) -> List[RetrievedContext]:
        if not self.records:
            return []

        query_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(query_vec, self.doc_matrix)[0]

        # Get top-k indices
        top_indices = np.argsort(sims)[::-1][:top_k]

        results = []
        for idx in top_indices:
            score = float(sims[idx])
            rec = self.records[idx]
            results.append(RetrievedContext(
                id=rec["id"],
                customer_query=rec["customer_query"],
                support_resolution=rec["support_resolution"],
                relevance_score=round(score, 4)
            ))

        return results
