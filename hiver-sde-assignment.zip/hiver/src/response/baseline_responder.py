"""
Baseline Response Generators:
1. CannedBaselineResponder (Trivial Baseline): Static canned response.
2. NearestNeighborBaselineResponder (Simple Baseline): Returns nearest historical resolution verbatim.
"""
from typing import List, Optional
from ..models import RetrievedContext
from .retrieval import HistoricalKnowledgeRetriever


class CannedBaselineResponder:
    """Trivial Baseline: Emits a canned support message regardless of query."""
    def __init__(self, canned_text: Optional[str] = None):
        self.canned_text = canned_text or (
            "Thanks for reaching out to Apple Support. We're here to help! "
            "Please send us a DM with your details so we can look into this with you: https://apple.co/DM"
        )

    def generate(
        self,
        customer_text: str,
        intent: str,
        contexts: Optional[List[RetrievedContext]] = None,
        is_escalated: bool = False,
        escalation_reason: str = "",
        **kwargs
    ) -> str:
        return self.canned_text


class NearestNeighborBaselineResponder:
    """Simple Baseline: Returns the top historical resolution verbatim."""
    def __init__(self, retriever: Optional[HistoricalKnowledgeRetriever] = None):
        self.retriever = retriever or HistoricalKnowledgeRetriever()

    def generate(
        self,
        customer_text: str,
        intent: str,
        contexts: Optional[List[RetrievedContext]] = None,
        is_escalated: bool = False,
        escalation_reason: str = "",
        **kwargs
    ) -> str:
        if contexts is None:
            contexts = self.retriever.retrieve(customer_text, top_k=1)

        if contexts and contexts[0].relevance_score > 0.05:
            return contexts[0].support_resolution

        # Fallback if no reasonable match
        return "We'd like to look into this with you. Please meet us in DM so we can troubleshoot together: https://apple.co/DM"
