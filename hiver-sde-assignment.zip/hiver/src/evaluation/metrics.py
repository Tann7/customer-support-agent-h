"""
Automated evaluation metrics for Intent Classification, Escalation Policy Safety,
and Lexical Reply Similarity.
"""
from typing import List, Dict, Any, Tuple
import math
from collections import Counter
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support


def compute_intent_metrics(y_true: List[str], y_pred: List[str]) -> Dict[str, float]:
    """Computes Accuracy, Macro Precision, Macro Recall, and Macro F1."""
    acc = float(accuracy_score(y_true, y_pred))
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    return {
        "accuracy": round(acc, 4),
        "macro_precision": round(float(p), 4),
        "macro_recall": round(float(r), 4),
        "macro_f1": round(float(f1), 4)
    }


def compute_escalation_metrics(y_true: List[str], y_pred: List[str]) -> Dict[str, float]:
    """
    Computes Escalation Policy performance with special focus on safety:
    - Precision, Recall, F1 for the 'escalate_to_human' class.
    - False Auto-Handle Rate (FAHR): proportion of cases that should have been escalated
      but were mistakenly auto-handled. (Critical safety hazard metric).
    """
    p, r, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, pos_label="escalate_to_human", average="binary", zero_division=0
    )
    
    # Calculate False Auto-Handle Count & Rate
    total_escalate_ground_truth = sum(1 for yt in y_true if yt == "escalate_to_human")
    false_auto_handles = sum(
        1 for yt, yp in zip(y_true, y_pred) if yt == "escalate_to_human" and yp == "auto_handle"
    )
    
    fahr = (false_auto_handles / total_escalate_ground_truth) if total_escalate_ground_truth > 0 else 0.0
    overall_acc = float(accuracy_score(y_true, y_pred))

    return {
        "escalation_accuracy": round(overall_acc, 4),
        "escalation_precision": round(float(p), 4),
        "escalation_recall": round(float(r), 4),
        "escalation_f1": round(float(f1), 4),
        "false_auto_handle_count": false_auto_handles,
        "false_auto_handle_rate": round(float(fahr), 4)
    }


def tokenize(text: str) -> List[str]:
    import re
    return re.findall(r"\b\w+\b", text.lower())


def calculate_rouge_l(ref: str, hyp: str) -> float:
    """Calculates Longest Common Subsequence (LCS) ROUGE-L F1."""
    ref_tokens = tokenize(ref)
    hyp_tokens = tokenize(hyp)
    if not ref_tokens or not hyp_tokens:
        return 0.0

    m, n = len(ref_tokens), len(hyp_tokens)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m):
        for j in range(n):
            if ref_tokens[i] == hyp_tokens[j]:
                dp[i + 1][j + 1] = dp[i][j] + 1
            else:
                dp[i + 1][j + 1] = max(dp[i + 1][j], dp[i][j + 1])
    lcs = dp[m][n]

    prec = lcs / n
    rec = lcs / m
    if prec + rec == 0:
        return 0.0
    return (2 * prec * rec) / (prec + rec)


def calculate_bleu(ref: str, hyp: str, max_n: int = 2) -> float:
    """Calculates simplified BLEU-1 and BLEU-2 score with brevity penalty."""
    ref_tokens = tokenize(ref)
    hyp_tokens = tokenize(hyp)
    if not ref_tokens or not hyp_tokens:
        return 0.0

    precisions = []
    for n in range(1, max_n + 1):
        ref_ngrams = Counter([tuple(ref_tokens[i:i+n]) for i in range(len(ref_tokens) - n + 1)])
        hyp_ngrams = Counter([tuple(hyp_tokens[i:i+n]) for i in range(len(hyp_tokens) - n + 1)])
        if not hyp_ngrams:
            precisions.append(0.0)
            continue
        overlap = sum(min(count, ref_ngrams[ng]) for ng, count in hyp_ngrams.items())
        total = sum(hyp_ngrams.values())
        precisions.append(overlap / total if total > 0 else 0.0)

    # Geometric mean
    if any(p == 0 for p in precisions):
        geo_mean = 0.0
    else:
        geo_mean = math.exp(sum(math.log(p) for p in precisions) / max_n)

    # Brevity penalty
    c = len(hyp_tokens)
    r = len(ref_tokens)
    bp = 1.0 if c > r else math.exp(1 - r / c) if c > 0 else 0.0

    return bp * geo_mean


def compute_lexical_metrics(refs: List[str], hyps: List[str]) -> Dict[str, float]:
    """Computes average ROUGE-L and BLEU-2 across reference-hypothesis pairs."""
    rouge_l_scores = [calculate_rouge_l(r, h) for r, h in zip(refs, hyps)]
    bleu_scores = [calculate_bleu(r, h) for r, h in zip(refs, hyps)]

    return {
        "avg_rouge_l": round(float(np.mean(rouge_l_scores)), 4),
        "avg_bleu_2": round(float(np.mean(bleu_scores)), 4)
    }
