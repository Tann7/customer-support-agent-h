"""
Baseline Intent Classifiers:
1. MajorityBaselineClassifier (Trivial Baseline): Always outputs the majority class.
2. TfidfLogisticBaselineClassifier (Simple Baseline): TF-IDF n-grams + Logistic Regression.
"""
from typing import List, Dict, Any, Optional
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from ..models import IntentResult, IntentType
from .taxonomy import ALL_INTENTS


class MajorityBaselineClassifier:
    """Trivial Baseline: Always predicts the most frequent intent."""
    def __init__(self, default_intent: IntentType = "software_os_issue"):
        self.majority_intent: IntentType = default_intent
        self.confidence: float = 0.35  # Empirical majority class prior

    def fit(self, texts: List[str], labels: List[str]):
        if not labels:
            return
        counts: Dict[str, int] = {}
        for l in labels:
            counts[l] = counts.get(l, 0) + 1
        self.majority_intent = max(counts.items(), key=lambda x: x[1])[0]
        self.confidence = counts[self.majority_intent] / len(labels)

    def predict(self, text: str) -> IntentResult:
        return IntentResult(
            intent=self.majority_intent,
            confidence=round(self.confidence, 4),
            explanation="Majority class baseline prediction."
        )


class TfidfLogisticBaselineClassifier:
    """Simple Baseline: TF-IDF feature extraction with Logistic Regression."""
    def __init__(self):
        self.pipeline = Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=5000, sublinear_tf=True)),
            ("clf", LogisticRegression(C=1.5, max_iter=500, class_weight="balanced"))
        ])
        self.is_fitted = False
        self.classes_: List[str] = ALL_INTENTS

    def fit(self, texts: List[str], labels: List[str]):
        self.pipeline.fit(texts, labels)
        self.classes_ = list(self.pipeline.named_steps["clf"].classes_)
        self.is_fitted = True

    def predict(self, text: str) -> IntentResult:
        if not self.is_fitted:
            raise RuntimeError("Classifier has not been fitted yet.")
        
        probas = self.pipeline.predict_proba([text])[0]
        best_idx = int(np.argmax(probas))
        best_class = self.classes_[best_idx]
        best_conf = float(probas[best_idx])

        return IntentResult(
            intent=best_class,
            confidence=round(best_conf, 4),
            explanation=f"TF-IDF Logistic Regression confidence: {best_conf:.2%}"
        )
