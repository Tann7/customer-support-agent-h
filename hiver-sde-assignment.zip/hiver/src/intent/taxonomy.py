"""
Intent taxonomy definitions, descriptions, boundary conditions, and representative seed terms
for AppleSupport customer communications.
"""
from typing import Dict, List, Any

ALL_INTENTS: List[str] = [
    "software_os_issue",
    "battery_power_hardware",
    "connectivity_sync",
    "account_billing_subscription",
    "device_setup_how_to",
    "complaint_feedback"
]

INTENT_TAXONOMY: Dict[str, Dict[str, Any]] = {
    "software_os_issue": {
        "label": "software_os_issue",
        "description": "Operating system bugs, app crashes, update failures, UI glitches, frozen screens, bootloops, or system storage issues.",
        "seed_keywords": [
            "update", "ios", "macos", "glitch", "crash", "frozen", "bootloop", "lag", 
            "apple logo", "screen", "keyboard", "autocorrect", "bug", "restore", "itunes error"
        ],
        "boundary_rule": "Select when the primary symptom is a software malfunction, OS behavior, or application crash. If battery draining is triggered specifically by an update, prioritize software_os_issue only if update-related."
    },
    "battery_power_hardware": {
        "label": "battery_power_hardware",
        "description": "Battery drain, chemical health, device overheating, charging cable/port issues, wireless charging, or physical hardware damage.",
        "seed_keywords": [
            "battery", "drain", "charge", "charger", "overheating", "hot", "lightning port", 
            "swelling", "swollen", "cracked screen", "shattered", "water damage", "power", "shut down"
        ],
        "boundary_rule": "Select when the complaint focuses on power, battery endurance, heat, charging hardware, or physical physical component damage."
    },
    "connectivity_sync": {
        "label": "connectivity_sync",
        "description": "Network connectivity, Wi-Fi, cellular reception, Bluetooth pairing, AirPods audio disconnects, AirDrop, iCloud syncing, or CarPlay.",
        "seed_keywords": [
            "wifi", "wi-fi", "bluetooth", "airdrop", "airpods", "disconnect", "carplay", 
            "icloud sync", "cellular", "no service", "lte", "pairing", "hotspot"
        ],
        "boundary_rule": "Select when devices fail to communicate, transmit data, sync across iCloud, or maintain wireless/cellular links."
    },
    "account_billing_subscription": {
        "label": "account_billing_subscription",
        "description": "Apple ID security, disabled accounts, two-factor authentication, iTunes charges, App Store subscriptions, refunds, or payment methods.",
        "seed_keywords": [
            "apple id", "locked", "disabled", "password", "two-factor", "2fa", "subscription", 
            "cancel", "refund", "charged", "billing", "credit card", "in-app purchase", "receipt"
        ],
        "boundary_rule": "Select whenever credentials, identity verification, subscriptions, or monetary charges are mentioned."
    },
    "device_setup_how_to": {
        "label": "device_setup_how_to",
        "description": "How-to guidance, feature discovery, data migration (Quick Start/Move to iOS), backup procedures, gestures, or setting configuration.",
        "seed_keywords": [
            "how do i", "how to", "transfer", "quick start", "setup", "screenshot", 
            "backup", "restore from backup", "apple pay setup", "enable", "switch"
        ],
        "boundary_rule": "Select when the customer is asking informational procedural instructions on how to use, configure, or migrate features on a working device."
    },
    "complaint_feedback": {
        "label": "complaint_feedback",
        "description": "General dissatisfaction with Apple policies, product design choices (e.g. headphone jack), service experience, pricing, or general venting.",
        "seed_keywords": [
            "terrible", "worst", "hate", "lawsuit", "boycott", "unacceptable", "ridiculous", 
            "headphone jack", "greedy", "manager", "disappointed", "complaint", "feedback"
        ],
        "boundary_rule": "Select when the user expresses subjective dissatisfaction, emotional venting, or policy complaints without requesting technical troubleshooting."
    }
}
