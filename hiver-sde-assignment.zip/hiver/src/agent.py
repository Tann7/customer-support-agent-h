"""
Unified AppleSupportAgent orchestrator integrating Intent Classification,
Historical Retrieval, Grounded Reply Generation, and Escalation Decision.
"""
import time
from typing import Optional, List

from .models import SupportAgentOutput, CustomerTweet, RetrievedContext
from .intent import HybridLLMIntentClassifier
from .response import HistoricalKnowledgeRetriever, GroundedReplyGenerator
from .policy import RiskAwarePolicyEngine


class AppleSupportAgent:
    """
    End-to-end AI Support Agent for Apple on Twitter.
    Orchestrates:
    - Stage 1: Intent classification & confidence scoring
    - Stage 2: RAG retrieval from historical knowledge base + grounded reply synthesis
    - Stage 3: Auto-handle vs human escalation policy decision with explicit justification
    """
    def __init__(
        self,
        classifier=None,
        retriever=None,
        responder=None,
        policy_engine=None
    ):
        self.retriever = retriever or HistoricalKnowledgeRetriever()
        self.classifier = classifier or HybridLLMIntentClassifier()
        self.responder = responder or GroundedReplyGenerator()
        self.policy_engine = policy_engine or RiskAwarePolicyEngine()

    def process(self, text: str, query_id: Optional[str] = None) -> SupportAgentOutput:
        start_time = time.perf_counter()

        # Stage 1: Classify Intent
        intent_res = self.classifier.predict(text)

        # Stage 2: Policy & Escalation Decision
        policy_res = self.policy_engine.decide(text, intent_res)
        is_escalated = (policy_res.decision == "escalate_to_human")

        # Stage 3: Retrieve Historical Precedents & Generate Grounded Reply
        retrieved_contexts: List[RetrievedContext] = self.retriever.retrieve(text, top_k=3)
        reply = self.responder.generate(
            customer_text=text,
            intent=intent_res.intent,
            contexts=retrieved_contexts,
            is_escalated=is_escalated,
            escalation_reason=policy_res.reason
        )

        latency_ms = (time.perf_counter() - start_time) * 1000.0

        return SupportAgentOutput(
            query_id=query_id,
            customer_text=text,
            intent=intent_res.intent,
            intent_confidence=intent_res.confidence,
            retrieved_contexts=retrieved_contexts,
            draft_reply=reply,
            escalation_decision=policy_res.decision,
            escalation_category=policy_res.category,
            escalation_reason=policy_res.reason,
            latency_ms=round(latency_ms, 2)
        )
