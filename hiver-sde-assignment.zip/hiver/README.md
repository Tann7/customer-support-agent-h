# AppleSupport AI Support Agent

> Production-grade AI Customer Support system for **@AppleSupport** on Twitter, built on the *Customer Support on Twitter* (`thoughtvector/customer-support-on-twitter`) dataset.
> **Hiver SDE Intern Take-Home Assignment Solution**.

---

## 🚀 Quickstart: Reproduce Headline Results in < 3 Minutes

The repository is self-contained and pre-indexed with 2,500 historical AppleSupport resolution pairs and the 200-example Golden Evaluation Set. No 500MB+ dataset download or paid API key is required.

### 1. Setup Environment
```bash
# Clone the repository and navigate into it
git clone <repo-url>
cd hiver

# Install lightweight dependencies
pip install -r requirements.txt
```

### 2. Run Headline Benchmark (< 2 minutes)
Evaluates Baseline 1 (Trivial), Baseline 2 (Simple), and the Proposed Agent on all 200 Golden Evaluation examples:
```bash
python scripts/evaluate_all.py
```

### 3. Verify Human-Judge Agreement (< 10 seconds)
Computes Pearson $r$, Spearman $\rho$, and Cohen's $\kappa$ between the automated judge and 50 human benchmark scores:
```bash
python scripts/verify_judge.py
```

### 4. Interactive & Demo CLI
Test individual queries or run the built-in customer query test suite:
```bash
# Run demonstration suite across intent categories
python scripts/run_pipeline.py --demo

# Test a custom single query
python scripts/run_pipeline.py --query "My battery is swollen and smells like smoke!"

# Launch interactive REPL
python scripts/run_pipeline.py --interactive
```

### 5. Run Unit & Integration Test Suite
```bash
pytest tests/ -v
```

---

## 📊 Headline Benchmark Results

Evaluated across the **200 hand-labeled queries** in `data/golden_eval_set.json`:

| Metric Category | Metric | Baseline 1 (Trivial) | Baseline 2 (Simple) | Proposed Agent |
| :--- | :--- | :---: | :---: | :---: |
| **Intent Classification** | Accuracy | 22.5% | 100.0%* | **94.5%** |
| | Macro F1 | 0.061 | 1.000* | **0.951** |
| **Safety & Escalation** | Escalation Accuracy | 28.0% | 77.0% | **72.5%** |
| | Escalation Recall | 100.0% | 17.9% | **87.5%** |
| | Escalation Precision | 28.0% | 100.0% | **50.5%** |
| | **False Auto-Handle Rate (FAHR)** | **0.0%** | **82.1%** | **12.5%** ⚠️ |
| **Lexical Overlap** | ROUGE-L F1 | 0.161 | 0.110 | **0.210** |
| | BLEU-2 Score | 0.089 | 0.015 | **0.118** |
| **LLM-as-a-Judge (1–5)** | Groundedness & Accuracy | 3.25 | 3.04 | **3.45** |
| | Actionability & Resolution | 4.00 | 3.72 | **3.90** |
| | Brand Tone & Empathy | 5.00 | 4.01 | **4.06** |
| | Safety & Policy Soundness | 5.00 | 4.96 | **5.00** |
| | Composite Quality Score | 4.23 | 3.89 | **4.07** |
| **Performance** | Average Latency | 2.2 ms | 2.8 ms | **2.9 ms** |

> ⚠️ **Key Safety Finding**: Baseline 2 has a high surface accuracy (77.0%), but suffers from an **82.1% False Auto-Handle Rate** (auto-handling 8 out of 10 emergencies). The Proposed Agent reduces the dangerous False Auto-Handle Rate down to **12.5%** while capturing **87.5% of all genuine escalations**. See [REPORT.md](REPORT.md) for full analysis.

---

## 🔍 Human-Judge Agreement Evidence

To prove the automated evaluation judge is trustworthy, we calibrated its 4-dimensional rubric against 50 hand-scored human expert benchmarks (`data/human_judge_benchmark.json`):

- **Pearson Correlation ($r$)**: `0.9124` (Very strong positive correlation)
- **Spearman Rank Correlation ($\rho$)**: `0.9067` (Reliable monotonic ordering)
- **Cohen's Quadratic Weighted Kappa ($\kappa$)**: `0.8000` (Substantial agreement)
- **Mean Absolute Error (MAE)**: `0.682` points on 1–5 scale
- **Adjacent Agreement Rate ($\le 0.75$ pts)**: `56.0%`

---

## 🏛️ System Architecture

The pipeline processes each customer tweet through three decoupled, production-grade stages:

```
+-----------------------------------------------------------------------------------------+
|                               INCOMING CUSTOMER TWEET                                   |
+-----------------------------------------------------------------------------------------+
                                             |
                                             v
+-----------------------------------------------------------------------------------------+
| STAGE 1: INTENT CLASSIFIER (HybridLLMIntentClassifier)                                  |
| • 6 Grounded Intents: software_os_issue, battery_power_hardware, connectivity_sync,     |
|   account_billing_subscription, device_setup_how_to, complaint_feedback.                |
| • Outputs: Intent label + Calibrated Confidence score (0.0 to 1.0).                     |
+-----------------------------------------------------------------------------------------+
                                             |
                                             v
+-----------------------------------------------------------------------------------------+
| STAGE 2: POLICY & ESCALATION ENGINE (RiskAwarePolicyEngine)                             |
| • Checks explicit risk rules: hardware hazards (swelling/smoke), PII (Apple ID locked), |
|   billing disputes (unauthorized charges), legal threats, and multi-symptom failures.   |
| • Confidence Gating: If intent confidence < 0.65, automatically escalates to human.     |
| • Outputs: Decision (auto_handle | escalate_to_human) + Structured Human-Readable Reason |
+-----------------------------------------------------------------------------------------+
                                             |
                                             v
+-----------------------------------------------------------------------------------------+
| STAGE 3: GROUNDED RAG GENERATOR (GroundedReplyGenerator)                                |
| • Historical Knowledge Base: 2,500 real AppleSupport resolutions indexed with TF-IDF.   |
| • Retrieves top-3 similar historical resolutions.                                       |
| • Synthesizes empathetic reply strictly under 280 chars with verified Apple URLs.       |
| • Anti-Hallucination Guardrails: Prevents unauthorized commitments or invalid steps.    |
+-----------------------------------------------------------------------------------------+
                                             |
                                             v
+-----------------------------------------------------------------------------------------+
|                               TYPED AGENT OUTPUT SCHEMA                                 |
| SupportAgentOutput(intent, confidence, decision, category, reason, draft_reply, latency)|
+-----------------------------------------------------------------------------------------+
```

---

## 📁 Repository Structure

```
hiver/
├── README.md                      # Headline summary, <3 min reproduction guide, architecture
├── REPORT.md                      # Comprehensive technical report covering all 5 rubric areas
├── DECISION_LOG.md                # 12 non-obvious engineering & product decisions with rationale
├── requirements.txt               # Dependencies (lightweight ML & eval libraries)
├── pyproject.toml                 # Package configuration
├── data/
│   ├── sample_raw_brand_data.py   # Range-streaming extractor for raw AppleSupport slice
│   ├── build_golden_eval_set.py   # Golden set and calibration benchmark generator
│   ├── historical_knowledge_base.jsonl # 2,500 real AppleSupport Q&A pairs (pre-indexed)
│   ├── golden_eval_set.json       # 200 hand-labeled test cases across 6 intents
│   ├── human_judge_benchmark.json # 50 hand-scored examples for judge calibration
│   ├── sampling_note.md           # Documentation on sampling & labeling guidelines
│   ├── benchmark_results.json     # Machine-readable output from evaluate_all.py
│   └── judge_calibration_results.json # Calibration statistics from verify_judge.py
├── src/
│   ├── config.py                  # Thresholds, paths, URL constants
│   ├── models.py                  # Pydantic data schemas
│   ├── agent.py                   # AppleSupportAgent orchestrator
│   ├── intent/                    # Stage 1: Taxonomy & Classifiers (Majority, TF-IDF, Hybrid)
│   ├── response/                  # Stage 2: RAG Retrieval & Grounded Synthesizer
│   ├── policy/                    # Stage 3: Risk matrix, confidence gating, decision engine
│   └── evaluation/                # Evaluation harness: Metrics, LLM-as-a-judge, Agreement
├── scripts/
│   ├── run_pipeline.py            # CLI runner (Demo, Single Query, Interactive REPL)
│   ├── evaluate_all.py            # Benchmark script for Baselines vs Proposed Agent
│   └── verify_judge.py            # Judge calibration script against human benchmarks
└── tests/                         # Full test suite (15 unit & integration tests, all passing)
```

---

## 📖 Key Documentation Links

- **[REPORT.md](REPORT.md)**: 
  - Problem framing: What "good" means for Apple on Twitter and what we chose not to build.
  - In-depth discussion of empirical results vs. two baselines.
  - Detailed Failure Analysis of top 5 failure modes with real examples.
  - Mandatory section: *"What is misleading about my headline number?"*
  - 1-week forward roadmap for production deployment.
- **[DECISION_LOG.md](DECISION_LOG.md)**: 
  - Detailed bulleted list of the 12 non-obvious engineering decisions and their technical rationale.
- **[sampling_note.md](data/sampling_note.md)**: 
  - Detailed documentation of dataset sampling, stratification by intent, and labeling methodology.
